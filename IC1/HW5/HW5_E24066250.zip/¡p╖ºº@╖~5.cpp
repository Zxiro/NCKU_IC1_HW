﻿#include<iostream>
#include<math.h>
using namespace std;
int times(int z)
{
	return pow(2, z) - 1;
}
void hanoi(int, char, char, char);
int tow(int, int[]);
void move(int, int,int,int[]);
int main(void)
{
	int n;
	int A[15];
	char fr;
	char to;
	int k,p;
	cout << "請輸入盤子個數(1~10): ";
	enter:cin >> n;
	if (n > 10 || n < 1)
	{
		cout << "數值錯誤再輸入一遍"<<endl;
		goto enter;
	}
	else;
	for (int i = 1; i <= n; i++)//將盤子放到A柱上A[]陣列意思是有多少盤子在A柱
	{
		A[i] = 'A';
	}
	cout << "移動指令請輸入大寫A B C一個字母\n"<<"若想看到解答，請在from中輸入0\n";
	redo:tow(n, A);
	while (1) 
	{
		cout << "from ";
		cin >> fr;
		if (fr != 'A'&&fr != 'B'&&fr != 'C')
		{
			if (fr == '0')
			{
				cout << "所需步數為" << times(n) << endl;
				cout << "正確解答如下:" << endl;
				hanoi(n, 'A', 'B', 'C');
				break;
				system("pause");
			}
			else
			{
				cout << "輸入錯誤!\n";
				goto redo;
			}
		}
		cout << "to ";
		cin >> to;
		if (to != 'A'&&to != 'B'&&to != 'C')
		{
			cout << "輸入錯誤!\n";
			goto redo;
		}
		move(fr, to, n, A);
		k = tow(n, A);
		if (k == 87)
		{
				break;
		}
	}
	 system("pause");
}
//cout << "所需步數為" << times(n) << endl;
//cout << "正確解答如下:" << endl;
//hanoi(n, 'A', 'B', 'C');

	
int tow(int n, int A[])//ABC三個柱子上有幾個盤子
{
	int a=0,Z[15],M=1,N=1,O=1,L;
	int b=0,X[15];
	int c=0,C[15];

	for (int i = 1; i <= n; i++)
	{
		if (A[i] == 'A')
		{
			a++;//幾個
			Z[a]=i;//幾號
		}
		else if (A[i] == 'B')
		{
			b++;
			X[b] = i;
		}
		else if (A[i] == 'C')
		{
			c++;
			C[c] = i;
		}
		
	}
	L = c;//C柱上有幾個盤子
	for (int i = n; i >= 1; i--)
	{
		if (i == a)
		{
			cout << Z[M]<<"\t";
			M++;
			a--;
			
		}
		else
		{
			cout << "0\t";
		}
		if (i == b)
		{
			cout << X[N] << "\t";
			N++;
			b--;
			
		}
		else
		{
			cout << "0\t";
		}
		if (i == c)
		{
			cout << C[O] << "\n";
			O++;
			c--;
			
		}
		else
		{
			cout << "0\n";
		}
	}
	if (L == n)//如果輸入的盤子個數==C柱上的盤子個數 則遊戲獲勝
	{
		cout << "you win!";
		return 87;
	}
}
void move(int fr, int to, int n, int A[])
{      
	int d = 0;
	for (int i = 1; i <= n; i++)
		{
			if (A[i] == fr)//移動的盤子
			{
				for (int f = 1; f < i; f++)
				{
					if (A[f] == to)//檢查移動式是否合法
						d = 1;
				}
				if (d == 1)
				{
					cout << "移動錯誤!!!" << endl;
					break;
				}
				A[i] = to;
				break;
			}
		}
}
void hanoi(int K, char P, char Q, char R ) {
	if (K == 1)
		cout << "盤 " << K << " 由 " << P << " 移至 " << R << "\n";
	else {//K=2時
		 //K=3時
		hanoi(K - 1, P, R, Q);//n-1個盤子要前往暫存區
		cout << "盤 " << K << " 由 " << P << " 移至 " << R << "\n";//Char R 為目標區 把第n個盤子移過去 n-1個盤子都在暫存區
		hanoi(K- 1, Q, P, R);//暫存區B的盤子要移往目標區C
	}
}
//以k=3為例(第3個的目標區是C)(暫存B)
//為了處裡第3-1個盤子(前2個的目標區是B)
//要先處理第2-1個(最頂的直接前往C)(下面那個盤子的暫存區)(第一個執行)
//第二個就可以前往他的目標區
//在它上面的要回來
//此時hanoi(3-1,p,r,q)就執行完(n-1個盤子移到中間暫存區的任務)
//接著執行第三個盤子直接前往c
//接著N-1個盤子的目標區為C(n-1個盤子移到目標區的任務)
// debug!!! 當一個輸入正確 另一個輸入錯誤時 正確的仍會移動