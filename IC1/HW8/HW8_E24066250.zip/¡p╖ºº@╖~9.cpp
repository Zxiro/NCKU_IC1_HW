#include<iostream>
#include<iomanip>
#include<stdlib.h>
using namespace std;
int row, col, c, det = 0,cou=0;
void mai(int, int);
void on(int, int);
void tw(int, int);
void th(int, int);
void fou(int, int);
void up(int, int);
void dow(int, int);
void rig(int, int);
void lef(int, int);
int a[8][8] = { 0 };
int main(void)
{
	srand(time(NULL));
start: cout << "  plz enter ur postition limit(1~7)" << endl << endl;
	cout << "  enter ur row:  ";
	cin >> row;
	cout << endl;
	cout << "  enter ur column:  ";
	cin >> col;
	cout << endl;
	if (row > 7 || col > 7 || row < 1 || col < 1)
	{
		cout << "  ERROR!!  " << endl;
		goto start;
	}
	a[row][col]++;
	for (int k = 1; k <= 7; k++)
	{
		a[row][k]++;
		a[k][col]++;
	}
	a[row][col]--;
	on(row, col);
	tw(row, col);
	th(row, col);
	fou(row, col);
	int dwarf = 1;
	int con = 1;
	int j = 0;
while (true)
	{
		res: for (int r = 1; r <= 7; r++)
		{
			while (true)
			{
				c = rand() % 7 + 1;
				switch (a[r][c])
			    {
				case 0:
				{
				    mai(r, c);
					if (det != 0)
					{
						break;
					}
					else if (det == 0)
					{
						a[r][c] = 2;
						dwarf++;
						con++;
						break;
					}
				}
			    case 1:
				{ 
					for (int v = 1; v <= 7; v++)
					{
						c = v;
						if (a[r][c] == 1)
						{
							cou++;
						}
						else if (a[r][c] != 1) 
						{
							continue;
						}
					}
					if (cou == 7)
					{
						j++;
						break;
					}
					else if (cou != 7) 
					{
						cou = 0;
						break;
					}
				}
	        	case 2:
				{ 
					con++;
					break;
				}
			  }
				if (con != 1)
				{ 
					con = 1;
					break;
				}
                if (j == 1) 
				{
					break;
				}
			}
			if (j == 1)
			{ 
				break;
			}
		}
		if (dwarf == 7) 
		{ 
			break;
		}
		else if (dwarf != 7||j==1)
		{ 
		dwarf = 1; 
		j = 0;
		for (int i = 1; i <= 7; i++)//test matrix
		{
			for (int k = 1; k <= 7; k++)
			{
				a[i][k] = 0;
			}
		}
		a[row][col]++;
		for (int k = 1; k <= 7; k++)
		{
			a[row][k]++;
			a[k][col]++;
		}
		a[row][col]--;
		on(row, col);
		tw(row, col);
		th(row, col);
		fou(row, col);
		}
		//system("pause");
	}

	for (int i = 1; i <= 7; i++)//test matrix
	{
		for (int k = 1; k <= 7; k++)
		{
			if (k == 7)
			{
				cout << setw(5) << a[i][k] << endl << endl;
			}
			else if (k != 7)
			{
				cout << setw(5) << a[i][k];
			}
		}
	}
	
	system("pause");
}
void  mai(int r, int c)
{
	on(r, c);
	tw(r, c);
	th(r, c);
	fou(r, c);
	up(r, c);
	dow(r, c);
	rig(r, c);
	lef(r, c);
}
void  on(int r, int c)
{
	if (a[r][c] != 1)
	{
		for (int k = 1; k <= 7; k++)
		{
			r++; c++;
			if (a[r][c] == 0)
			{
				if (r < 1 || r>7 || c < 1 || c>7)
				{
					break;
				}
				else
					a[r][c]++;
			}
			else if (a[r][c] == 1)
			{
				continue;
			}
			else if (a[r][c] == 2)//���~
			{
				det++;
				break;
			}
		}
	}
}
void tw(int r, int c)
{
	if (a[r][c] != 1)
	{
		for (int k = 1; k <= 7; k++)
		{
			r--; c++;
			if (a[r][c] == 0)
			{
				if (r < 1 || r>7 || c < 1 || c>7)
				{
					break;
				}
				a[r][c]++;
			}
			else if (a[r][c] == 1)
			{
				continue;
			}
			else if (a[r][c] == 2)//���~
			{
				det++;
				break;
			}
		}
	}
}
void  th(int r, int c)
{
	if (a[r][c] != 1)
	{
		for (int k = 1; k <= 7; k++)
		{
			r--; c--;
			if (a[r][c] == 0)
			{
				if (r < 1 || r>7 || c < 1 || c>7)
				{
					break;
				}
				a[r][c]++;
			}
			else if (a[r][c] == 1)
			{
				continue;
			}
			else if (a[r][c] == 2)//���~
			{
				det++;
				break;
			}
		}
	}
}
void  fou(int r, int c)
{
	if (a[r][c] != 1)
	{
		for (int k = 1; k <= 7; k++)
		{
			r++; c--;
			if (a[r][c] == 0)
			{
				if (r < 1 || r>7 || c < 1 || c>7)
				{
					break;
				}
				a[r][c]++;
			}
			else if (a[r][c] == 1)
			{
				continue;
			}
			else if (a[r][c] == 2)//���~
			{
				det++;
				break;
			}
		}
	}
}
void  dow(int r, int c)
{
	if (a[r][c] != 1)
	{
		for (int k = 1; k <= 7; k++)
		{
			r++;
			if (a[r][c] == 0)
			{
				if (r < 1 || r>7 || c < 1 || c>7)
				{
					break;
				}
				a[r][c]++;
			}
			else if (a[r][c] == 1)
			{
				continue;
			}
			else if (a[r][c] == 2)//���~
			{
				det++;
				break;
			}
		}
	}
}
void  rig(int r, int c)
{
	if (a[r][c] != 1)
	{
		for (int k = 1; k <= 7; k++)
		{
			c++;
			if (a[r][c] == 0)
			{
				if (r < 1 || r>7 || c < 1 || c>7)
				{
					break;
				}
				a[r][c]++;
			}
			else if (a[r][c] == 1)
			{
				continue;
			}
			else if (a[r][c] == 2)//���~
			{
				det++;
				break;
				//continue;
			}
		}
	}
}
void  lef(int r, int c)
{
	if (a[r][c] != 1)
	{
		for (int k = 1; k <= 7; k++)
		{
			c--;
			if (a[r][c] == 0)
			{
				if (r < 1 || r>7 || c < 1 || c>7)
				{
					break;
				}
				a[r][c]++;
			}
			else if (a[r][c] == 1)
			{
				continue;
			}
			else if (a[r][c] == 2)//���~
			{
				det++;
				break;
				//continue;
			}
		}
	}
}
void  up(int r, int c)
{
	if (a[r][c] != 1)
	{
		for (int k = 1; k <= 7; k++)
		{
			r--;
			if (a[r][c] == 0)
			{
				if (r < 1 || r>7 || c < 1 || c>7)
				{
					break;
				}
				a[r][c]++;
			}
			else if (a[r][c] == 1)
			{
				continue;
			}
			else if (a[r][c] == 2)//���~
			{
				det++;
				break;
			}
		}
	}
}
