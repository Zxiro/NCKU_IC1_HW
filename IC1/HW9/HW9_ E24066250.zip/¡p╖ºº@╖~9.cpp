#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;
int main(void)
{
	string line;
	vector<vector<int> >info;
	vector<vector<int> >info1;
	fstream File;
	float min_support;
	float min_conf;
	File.open("input.txt.txt", ios::in);
	if (!File) 
	{
		cout << "Fail to open file " << endl;
	}
	while (getline(File, line, '\n'))
	{
	vector<int> temp;
	vector<int> temp1;
	for (int i = 0; i<line.length(); i++)//���Ƴ����L�@��
	  {
	if (isdigit(line[i]))
	 {
	 temp.push_back(line[i]);
	 temp1.push_back(line[i]-48);
	 }
	    }
	info.push_back(temp);
	info1.push_back(temp1);
	}
	for (int i = 0; i < info1.size(); i++)//�ˬd���LŪ��
	{
		for (int j = 0; j < info1[i].size(); j++)
		{
			cout << info1[i][j] << " ";
		}
		cout << "\n";
	}

	sup:cout << "�п�J min_support"<<endl;
	cin >> min_support;
	if (min_support >=1||min_support<=0)
	{
		cout << "input error!"<<endl;
		goto sup;
	}
conf:cout << "�п�J min_conf" << endl;
	cin >> min_conf;
	if (min_conf >= 1 ||min_conf <= 0)
	{
		cout << "input error!";
		goto conf;
	}

	vector<vector<int>>kinds;//�䦳�X�ذӫ~
	vector<int>tempo(1);
	tempo[0] = info1[0][0];
	kinds.push_back(tempo);
	for (int j = 0; j < info1.size(); j++) 
	{
		for (int z = 0; z < info1[j].size(); z++) //�䧹��Ӹ�ư}�C
		{
			for (int k = 0; k < kinds.size(); k++)
			{      //�䦳�L����
				if (info1[j][z] == kinds[k][0])//�p�G�����@�˴N���L 
				{
					break;
				}
				else if (k == kinds.size() - 1)//���̫�@�����o�{�S���@�˦s�J�����}�C
				{  
					/*vector <int> temp2;*/
					tempo.push_back(info1[j][z]);
					kinds.push_back(tempo);
				}
			}
		}
	}

	vector <vector<int>> kindspeo(kinds.size());//�U�ذӫ~���X�H
	for (int i = 0; i < kindspeo.size(); i++)
	{
		for (int j = 0; j < info1.size(); j++)
		{
			for (int k = 0; k <info1[j].size(); k++)
			{
				if (kinds[i][0] == info1[j][k])
				{
					kindspeo[i].push_back(j);
					break;
				}
			}
		}
	}
	system("pause");
}