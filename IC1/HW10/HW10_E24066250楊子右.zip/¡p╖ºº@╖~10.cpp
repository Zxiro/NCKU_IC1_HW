#include<iostream>
#include<vector>
#include<fstream>
#include<string>
#include <algorithm>
using namespace std;
string x, y,lcs;
vector<vector<int>>table;
void Long(int m, int n, string b, string c)
{
	vector<vector<int>>table(m + 1, vector<int>(n + 1));
	for (int i = 0; i<m + 1; ++i)
	{
		for (int j = 0; j<n + 1; ++j)
		{
			if (i == 0 || j == 0)
				table[i][j] = 0;

			else if (b[i - 1] == c[j - 1])
				table[i][j] = table[i - 1][j - 1] + 1;

			else
				table[i][j] = max(table[i - 1][j], table[i][j - 1]);
		}
	}
	cout << table[m][n] << endl;
}
void final(int, int, string);
string rev(string);
int main(void)
{
	cout << "max(0,5000)==" << max(0, 5000) << endl;//max���
	fstream file;
	string line;
	vector<vector<char>>wordt;
	file.open("xx.txt", ios::in);
	while (getline(file, line, '\n'))//���@������ɮ�
	{
		vector<char>word1;
		for (int i = 0; i < line.length(); i++)
		{
			if (isdigit(line[i]))
			{
				break;
			}
			else;
			word1.push_back(line[i]);
		}
		wordt.push_back(word1);
	}
	for (int k = 1; k < wordt.size(); k++)
	{
		for (int i = 0; i < wordt[k].size(); i++)
		{
			cout << wordt[k][i];
		}
		cout << endl;
	}
	
	for (int o = -1; o <= 3; o = o + 2)
	{
		for (int k = o + 2; k < wordt.size(); k++)
		{
			for (int i = 0; i < wordt[k].size(); i++)
			{
				x.push_back(wordt[k][i]);
			}
			for (int i = 0; i < wordt[k + 1].size(); i++)
			{
				y.push_back(wordt[k + 1][i]);
			}
			int m = x.length(), n = y.length();
			
			Long(m, n, x, y);
			final(m, n, lcs);
			break;
		}
		x, y = '0';
	}
	string cba= "cba";
	rev(cba);
	system("pause");
	return 0;
}
void final(int i, int j, string k)
{
	vector<vector<int>>table(i+1, vector<int>(j+1));
	while (i > 0 && j > 0)
	{
		if (x[i - 1] == y[j - 1])//�P�˪��O�U��
		{
			k.push_back(x[i - 1]);
			--i;
			--j;
		}
		else
		{
			if (table[i - 1][j] > table[i][j - 1])//�D�j��
				--i;
			else if (table[i - 1][j] < table[i][j - 1])
				--j;
			else
			{
				final(i - 1, j, k);
				final(i, j - 1, k);//�a�^again
				return;
			}
		}
	}
	cout << rev(k);
}
string rev(string str)
{
	int beg = 0;
	int end = str.length() - 1;
	while (beg < end)
	{
		char temp = str[beg];
		str[beg] = str[end];
		str[end] = temp;
		++beg;
		--end;
	}
	cout << str;
	return str;
	
}
