#include <iostream>
#include<stdlib.h>
#include<vector>
#include<time.h>
using namespace std;
int poor(const vector < vector<char> > &, char, char);//�^�Ǿ�ƭ�
int poor(const vector < vector<char> > &b, char mydisc, char yourdisc) {
	static const char me = mydisc; //Record the disc type main function assigns for this AI. It never changes once assigned
	static const char opponent = yourdisc; //Record the disc type main function assigns for another AI. It never changes once assigned
	int column = -1;
	//Write a simple AI for testing
	srand(time(NULL));
		int dec = rand() % 6;//0~6����l���H����@�Ӯ�l�U
		if (b[0][dec] == 0) 
		{
			column = dec;
		}
	//column = 5;
	return column;
	//Write a simple AI for testing
}