#include <iostream>
#include <vector>
#include<time.h>
using namespace std;
int E24066250(const vector < vector<char> > &b, char, char);
//void gamewinner(int, int, char);
int wincount=0;
int tempmax = 0;
int win = 0,temp=-1;

	

int E24066250(const vector < vector<char> > &b, char mydisc, char yourdisc)
{

	srand(time(NULL));
	static const char me = mydisc; //Record the disc type main function assigns for this AI. It never changes once assigned
	static const char opponent = yourdisc; //Record the disc type main function assigns for another AI. It never changes once assigned
	int column = -1,icount=0;
	//Write your AI here
	//yourdisc = 'X';
	//mydisc = 'O';
	for (int i = 0; i < 7; i++) 
	{
		if (b[5][i] == 0) 
		{
			icount++;//�p�G�O�ڥ��� �h�U����
		}
	}
	if (icount == 7)
	{
		column = 3;
		return column;
	}
	else
		//a = gamewinner()height[p1];d = p1;int wincount=0;
		for (int row = 0; row < 6; row++)
		{
			for (int col = 0; col < 7; col++)
			{
				if (b[row][col] == yourdisc)
				{  /*//�H�@�Ӿ���h�P�_�n����x������ by�[�v���ƧP�_*/
					
						//a = row;d = col;int wincount=0;	
					    int a = row, d = col; char c = yourdisc;
						vector<int>winstorage(8, 0);
						int wincount = 0;
						for (int z = 1; z <= 3; z++)//�W
						{
							if (a - z < 0)
							{
								break;
							}
							else
							if (b[a - z][d] == c)
							{
								cout << "got" << endl;
								wincount++;
							}
							else if (b[a - z][d] != c)
							{							
								break;
							}
						}
					  if (wincount != 0)
						{
						  if (wincount == 2)
						  {
							  if (b[0][d] == 0)
							  {
								  cout << "d" << endl;
								  column = d;

								  return column;
							  }
							  else
							re: column = rand() % 7;
							  if (b[0][column] != 0)
							  {
								  goto re;
							  }
							  else
							  return column;
						  }						
						}
					  for (int z = 1; z <= 3; z++)//�U
					  {
						  if (a + z > 5)
						  {
							  break;
						  }
						  else
							  if (b[a + z][d] == c)
							  {
								  cout << "got" << endl;
								  wincount++;
							  }
							  else if (b[a + z][d] != c)
							  {
								  break;
							  }
					  }
					  if (wincount != 0)
					  {
						  if (wincount == 2)
						  {
							   if (b[0][d] ==0)
							  {
								  cout << "d" << endl;
								  column = d;
								
									  return column;
							  }
							  else
							re1: column = rand() % 7 ;
							  if (b[0][column] != 0)
							  {
								  goto re1;
							  }
							  else
							  return column;
						  }
					  }
						for (int z = 1; z <= 3; z++)//��
						{
							if (d - z < 0)
							{
								break;
							}
							else

								if (b[a][d - z] == c)
								{
									wincount++;
								}
								else if (b[a][d - z] != c)
								{									
									break;
								}

						}
						if (wincount > 1)
						{
							if (wincount == 2)
							{
								if (d - 3 < 6)
								{
									if (b[0][d-3] == 0)
									{
										column = d - 3;
									
									}
								}
								else
									break;
							}
						}
						for (int z = 1; z <= 3; z++)//�k
						{
							if (d + z > 6)
							{
								break;
							}
							else
								if (b[a][d + z] == c)
								{

									wincount++;
								}
								else if (b[a][d + z] != c)
								{								
									break;
								}
						}
						if (wincount != 0)
						{
							if (wincount == 2)
							{
								if (d + 3 < 6) 
								{
									if (b[0][d + 3] == 0)
									{
										column = d + 3;
										return column;
									}
								}
								else
									break;
							}							
						}
					}
				}
			}
	if (tempmax == 0)
	{
		for (int row = 0; row < 6; row++)
		{
			for (int col = 0; col < 7; col++)
			{
				if (b[row][col] == mydisc)
				{
					int a = row, d = col; char c = mydisc;
					vector<int>winstorage1(8, 0);
					int win = 0;
					for (int z = 1; z <= 3; z++)//�W
					{
						if (a - z < 0)
						{
							break;
						}
						else
							if (b[a - z][d] == c)
							{
								cout << "got" << endl;
								win++;
							}
							else if (b[a - z][d] != c)
							{
								break;
							}
					}
					if (win != 0)
					{
						if (win == 2)
						{
							if (b[0][d] == 0)
							{
								cout << "d" << endl;
								column = d;

								return column;
							}
							else
								re2: column = rand() % 7;
							if (b[0][column] != 0)
							{
								goto re2;
							}
							else
							return column;
						}
						winstorage1[1] = d;
						win = 0;
					}
					for (int z = 1; z <= 3; z++)//�U
					{
						if (a + z > 5)
						{
							break;
						}
						else
							if (b[a + z][d] == c)
							{
								cout << "got" << endl;
								win++;
							}
							else if (b[a + z][d] != c)
							{
								break;
							}
					}
					if (win != 0)
					{
						if (win == 2)
						{
							if (b[0][d] == 0)
							{
								cout << "d" << endl;
								column = d;

								return column;
							}
							else
								re3: column = rand() % 7;
							if (b[0][column] != 0)
							{
								goto re3;
							}else
							return column;
						}
					}
					for (int z = 1; z <= 3; z++)//��
					{
						if (d - z < 0)
						{
							break;
						}
						else
							if (b[a][d - z] == c)
							{
								win++;
							}
							else if (b[a][d - z] != c)
							{							
								break;
							}
					}
					if (win > 1)
					{
						if (win == 2)
						{

								if (b[0][d-3] == 0)
								{
									cout << "d" << endl;
									column = d;
									return column;
								}
								else
									column = d + 1;
								if (d + 1 > 6)
								{
									column = d - 1; return column;
								}
								return column;
								
						}
						else
							winstorage1[2] = d - 1;
						win = 0;
					}
					for (int z = 1; z <= 3; z++)//�k
					{
						if (d + z > 6)
						{
							break;
						}
						else
							if (b[a][d + z] == c)
							{
								win++;
							}
							else if (b[a][d + z] != c)
							{								
								break;
							}
					}
					if (win != 0)
					{
						if (win == 2)
						{
							if (b[0][d + 3] == 0)
							{
								cout << "d" << endl;
								column = d;
								return column;
							}
							else
								column = d + 1;
							if (d + 1 > 6)
							{
								column = d - 1; return column;
							}
							return column;
						}
						else
						winstorage1[3] = d + 1;
						win = 0;
					}
					for (int w = 0; w < 7; w++)
					{
						if (winstorage1[w] > temp)
						{
							cout << winstorage1[w] << "tt" << endl;
							temp = winstorage1[w];
						}
					}
					cout << temp << endl;
					column = temp;
					return column;
				}
				else if (row == 5 & col == 6)
				{
					column = 3;
					cout << "fail" << endl;
					return column;
				}
			}
		}
	}
	//return column;
	else
		tempmax = rand() % 7;
	column =tempmax;
	int ch = 1;
	for (int i = 0; i < 6; i++) 
	{
		if (b[i][column] == yourdisc) 
		{
			ch++;
		}
	}
	if (ch>6)
	{
		column = rand() % 7;
	}
	cout << column <<"c"<< endl;

	//Write your AI here

	return column;
}
