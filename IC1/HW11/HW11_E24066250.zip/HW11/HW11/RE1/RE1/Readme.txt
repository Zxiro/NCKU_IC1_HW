              First decide which column you want to put in .
              Then enter th number 0~6.
              That will decide your column.
              In order to win the game.
              You need to make 4 of your disks in a row.
              And stop your enemy from making it.
              Good Luck!
