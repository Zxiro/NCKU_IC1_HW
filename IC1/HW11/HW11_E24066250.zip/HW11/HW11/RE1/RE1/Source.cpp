#include<iostream>
#include<vector>
#include<fstream>
#include<string>
using namespace std;
int gamewinner(int, int, int);
void boardv();
vector<int>height(8, 5);
vector<vector<int>>board(6, vector<int>(7, 0));
int wincount = 0;
int main(void)
{
	fstream file;
	string rule;
	file.open("Readme.txt", ios::in);
	if (!file)
	{
		cout << "Fail to open the file!" << endl;
		system("pause");
		return 0;
	}
	while (getline(file, rule, '\n'))
	{
		cout << rule << endl;
	}
	int p1, p2, drawcount = 0;
	for (int i = 0; i <= 6; i++)
	{
		for (int k = 0; k <= 5; k++)
		{
			board[k][i] = 0;
		}
	}
	cout << endl << endl;
	while (true)
	{
	p1:cout << "It's player1's turn!" << endl;
		cin >> p1;
		if (p1 < 0 || p1>6)
		{
			cout << "�п�J���T����!" << endl;
			goto p1;
		}
		board[height[p1]][p1] = 1;
		gamewinner(height[p1], p1, 1);
		if (wincount != 0)
		{
			cout << "player 1 win!" << endl;
			boardv();
			system("pause");
			return 0;
		}
		boardv();
		system("pause");
		system("cls");
		height[p1]--;
	p2:cout << "It's player2's turn!" << endl;
		cin >> p2;
		if (p2 < 0 || p2>6)
		{
			cout << "�п�J���T����!";
			goto p2;
		}
		board[height[p2]][p2] = 2;
		gamewinner(height[p2], p2, 2);
		if (wincount != 0)
		{
			cout << "player 2 win!" << endl;
			boardv();
			system("pause");
			return 0;
		}
		height[p2]--;
		boardv();
		for (int i = 0; i < 6; i++)
		{
			for (int j = 0; j < 7; j++)
			{
				if (board[i][j] != 0)
				{
					drawcount++;
				}
			}
		}
		if (drawcount == 42)
		{
			cout << "Draw Game!!" << endl;
			system("pause");
			return 0;
		}
		system("pause");
		system("cls");
	}
}
int gamewinner(int a, int b, int c)
{
	//a = height[p1];b = p1;int wincount=0;
	for (int z = 1; z <= 3; z++) //�U
	{
		if (a + z > 5)
		{
			break;
		}
		else

			if (board[a + z][b] == c)
			{
				wincount++;
			}
			else if (board[a + z][b] != c)
			{
				wincount = 0;
				break;
			}
		if (wincount == 3)
		{
			return wincount;
		}
	}
	for (int z = 1; z <= 3; z++)//�W
	{
		if (a - z < 0)
		{
			break;
		}
		else

			if (board[a - z][b] == c)
			{
				wincount++;

			}
			else if (board[a - z][b] != c)
			{
				wincount = 0;
				break;
			}
		if (wincount == 3)
		{
			return wincount;
		}
	}
	for (int z = 1; z <= 3; z++)//��
	{
		if (b - z < 0)
		{
			break;
		}
		else

			if (board[a][b - z] == c)
			{
				wincount++;
			}
			else if (board[a][b - z] != c)
			{
				wincount = 0;
				break;
			}
		if (wincount == 3)
		{
			return wincount;
		}
	}
	for (int z = 1; z <= 3; z++)//�k
	{
		if (b + z > 6)
		{
			break;
		}
		else

			if (board[a][b + z] == c)
			{
				wincount++;
			}
			else if (board[a][b + z] != c)
			{
				wincount = 0;
				break;
			}
		if (wincount == 3)
		{
			return wincount;
		}
	}
	for (int z = 1; z <= 3; z++)//�k�W
	{
		if (a - z <0 || b + z>6)
		{
			break;
		}
		else

			if (board[a - z][b + z] == c)
			{
				wincount++;
			}
			else if (board[a - z][b + z] != c)
			{
				wincount = 0;
				break;
			}
		if (wincount == 3)
		{
			return wincount;
		}
	}
	for (int z = 1; z <= 3; z++)//�k�U
	{
		if (a + z > 5 || b + z>6)
		{
			break;
		}
		else

			if (board[a + z][b + z] == c)
			{
				wincount++;
			}
			else if (board[a + z][b + z] != c)
			{
				wincount = 0;
				break;
			}
		if (wincount == 3)
		{
			return wincount;
		}
	}
	for (int z = 1; z <= 3; z++)//���U
	{
		if (a + z > 5 || b - z<0)
		{
			break;
		}
		else

			if (board[a + z][b - z] == c)
			{
				wincount++;
			}
			else if (board[a + z][b - z] != c)
			{
				wincount = 0;
				break;
			}
		if (wincount == 3)
		{
			return wincount;
		}
	}
	for (int z = 1; z <= 3; z++)//���W
	{
		if (a - z <0 || b - z<0)
		{
			break;
		}
		else

			if (board[a - z][b - z] == c)
			{
				wincount++;
			}
			else if (board[a - z][b - z] != c)
			{
				wincount = 0;
				break;
			}
		if (wincount == 3)
		{
			return wincount;
		}
	}
	return wincount;
}
void boardv()
{
	cout << "      0 1 2 3 4 5 6" << endl;
	cout << "     ===============" << endl;
	for (int i = 0; i < 6; i++)
	{
		cout << "  " << i << "  |";
		for (int j = 0; j < 7; j++)
		{
			cout << board[i][j] << "|";
		}
		cout << endl;
	}
	cout << "     ===============" << endl;
}