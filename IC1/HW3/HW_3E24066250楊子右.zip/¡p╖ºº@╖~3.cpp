#include<iostream>
using std::cin;
using std::cout;
int main(void)
{
	int n;
	int f0 = 0;
	int f1 = 1;
	int A = 0;
	int B = 1;
	int S = 0;
	cout << "��J�j�󵥩�0�����@���:\n";
	cin >> n;
	if (n==0||n==1)
	{
	cout << f0;
	cout << f0 << " " << f1 << " ";
	}
	if (n >= 2) {
		cout << f0 << " ";
		for (int k = 0;n-1>k; k++){
			S = A + B;
			cout << S << " ";
			B = A;
			A = S;
		}
	}
	system("pause");
}

 
