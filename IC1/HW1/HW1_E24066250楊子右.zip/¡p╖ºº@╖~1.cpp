#include<iostream>
using namespace std;
int main(void)
{
	cout << "= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = \n\n";
	cout << "||�W�r:���l�k                                                                                               ||\n\n";
	cout << "|| English Name:Yang Zih You or Jack                                                                        ||\n\n";
	cout << "|| HomeTown:Taichung Taiwan                                                                                 ||\n\n";
	cout << "|| Garduated From:��߿��j����/SHCH                                                                         ||\n\n";
	cout << "|| Hobby:swimming/basketball/baseball/LOL/reading novel                                                     ||\n\n";
	cout << "|| Which Kinds Of EE Knowledge i wants to learn in the future:Artifcial intelligence and Virtual Reality    ||\n\n";
	cout << "|| It is end of my self introduction thanks!                                                                ||\n\n";
	cout << "= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = \n\n";
		system("pause");
	return 0;
}