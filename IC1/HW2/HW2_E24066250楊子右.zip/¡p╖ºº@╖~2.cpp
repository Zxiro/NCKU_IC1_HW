#include<iostream>;
using namespace std;
int main(void)
{
start:
	cout << "please enter number 0 ~ 5\n";
	int num;
	cin >> num;
	if(num==0 || num==1 || num==2 || num==3 || num==4 || num==5)
	{
		if (num == 0)
		{
			cout << "= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = \n\n";
			cout << "||�W�r:���l�k                                                                                               ||\n\n";
			cout << "|| English Name:Yang Zih You or Jack                                                                        ||\n\n";
			cout << "|| HomeTown:Taichung Taiwan                                                                                 ||\n\n";
			cout << "|| Garduated From:��߿��j����/SHCH                                                                         ||\n\n";
			cout << "|| Hobby:swimming/basketball/baseball/LOL/reading novel                                                     ||\n\n";
			cout << "|| Which Kinds Of EE Knowledge i wants to learn in the future:Artifcial intelligence and Virtual Reality    ||\n\n";
			cout << "|| It is end of my self introduction thanks!                                                                ||\n\n";
			cout << "= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = \n\n";
		}
		else if (num == 1)
			cout << "*\n";
		else if (num == 2)
			cout << "**\n";
		else if (num == 3)
			cout << "***\n";
		else if (num == 4)
			cout << "****\n";
		else if (num == 5)
			cout << "*****\n";
	}
	else
	{
		cout << "please enter the right number\n";
			goto start;
	}
	system("pause");
	return 0;
}
